import { GuidelineType } from '../dto/guideline-type';
import { GuidelineVersion } from '../dto/guideline-version';

export interface GuidelineListData {
  guidelineType: GuidelineType;
  latestVersion: GuidelineVersion;
  guidelineVersions: GuidelineVersion[];
}
