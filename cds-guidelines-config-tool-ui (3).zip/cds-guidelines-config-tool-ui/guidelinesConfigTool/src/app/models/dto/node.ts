import { Resource } from './resource';

export class Node implements Resource {
  id: number;
  index: number;
  version: number;
  content: string;
  footnotes: number[];
  outgoingNodeIds: number[];
  section: number;
  tableItem: number;
  guidelineId: number;
  createdBy?: Date;
  createdDate?: Date;
  lastModifiedBy?: Date;
  lastModifiedDate?: Date;
}



