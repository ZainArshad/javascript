export interface Resource {
  id: number;
  parentId?: number;
}
