import { Resource } from './resource';
import { GuidelineVersion } from './guideline-version';
import { TableItem } from './table-item';

export class Guideline implements Resource {
  id: number;
  createdDate: Date;
  guidelineVersion: GuidelineVersion;
  tableItems: TableItem[];
  removed: boolean;
}
