import { Resource } from './resource';
import { GuidelineType } from './guideline-type';

export class GuidelineVersion implements Resource {
  id: number;
  guidelineTypeId: number;
  guidelineType: GuidelineType;
  providerVersion: string;
  createdDate: Date;
  lastModifiedDate: Date;
  updates: string[];
  removed: boolean;
}
