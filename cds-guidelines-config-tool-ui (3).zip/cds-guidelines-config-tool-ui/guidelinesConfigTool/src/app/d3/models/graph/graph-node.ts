import { Point } from './point';
import { Size } from './size';

export interface GraphNode {
  id: number;
  content: any;
  children?: GraphNode[];
  parentId?: number;
  size: Size;
  width?: number;
  height?: number;
  x?: number;
  y?: number;
  position: Point;
  vx?: number;
  vy?: number;
  fx?: number | null;
  fy?: number | null;
}
