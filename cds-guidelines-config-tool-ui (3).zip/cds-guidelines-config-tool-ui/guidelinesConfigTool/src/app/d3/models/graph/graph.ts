import { GraphNode } from './graph-node';
import { GraphEdge } from './graph-edge';
import { Size } from './size';

export interface Graph {
  nodes: GraphNode[];
  edges: GraphEdge[];
  size: Size;
  center?: number;
  startingNodesCenterX?: number;
}
