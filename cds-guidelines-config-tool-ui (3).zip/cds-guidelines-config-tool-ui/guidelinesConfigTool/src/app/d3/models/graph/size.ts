export interface Size {
  width: number;
  height: number;
}
