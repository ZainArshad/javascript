import { ElementRef } from '@angular/core';
import * as d3 from 'd3';
import { GraphNode } from './models/graph';

import { MatDialog } from '@angular/material/dialog';
import { DialogBoxComponent } from '../components/gct-editor/dialog-box/dialog-box.component';

const longText =
  '<span>This is new Text box hello[&times;10<sup>-15</sup> ss<sup>-1</sup>]</span>';

export const createGraphNode = (
  svgRef: ElementRef<SVGElement>,
  gNode: GraphNode,
  dialog: MatDialog
): void => {
  console.log('hi',svgRef);
  const longText =
    '<span>This is new Text box hello[&times;10<sup>-15</sup> ss<sup>-1</sup>]</span>';
  const someWidth = 212;

  let totHeight = 0;

  let count = 1;
  let lineX1 = 180;
  let lineX2 = 180;
  let lineY1 = 0;
  let lineY2 = 60;

  let posX = gNode.x;
  let posY = gNode.y;

  const block = d3
    .select(svgRef.nativeElement)
    .append('div')
    .attr('class', 'main_svg_block');

  const main = d3
    .select(svgRef.nativeElement)
    .append('div')
    .attr('class', 'main_block');

  const svgContainer = block
    .append('svg')
    .attr('width', 2000)
    .attr('height', 500);

  const g = svgContainer
    .append('g')
    .attr('transform', 'translate(20,' + totHeight + ')');

    g.append('rect')

  const rectangleSolid = g
    .append('rect')
    .attr('x', gNode.x)
    .attr('y', gNode.y)
    .attr('width', gNode.width)
    .attr('height', gNode.height)
    .attr('style', 'fill:none')
    .attr('opacity', 0.3)
    .attr('stroke', 'black')
    .attr('stroke-width', '1');

  const text = g
    .append('foreignObject')
    .attr('width', 200)
    .attr('height', 100)
    .attr('x', 60)
    .attr('y', 80)
    .attr('id', 'textBox')
    //.attr('style', 'grey')
    .append('xhtml:body')
    .html('<span> hello[&times;10<sup>-15</sup> ss<sup>-1</sup>]</span>');
  // .html(longText);

  const editImg = g
    .append('svg:image')
    .attr('class', 'textEdit')
    .attr('x', 235)
    .attr('y', 75)
    .attr('width', 24)
    .attr('height', 24)
    .attr('xlink:href', './assets/edit-24-px.svg');

  g.append('svg:image')
    .attr('x', 250)
    .attr('y', 55)
    .attr('width', 24)
    .attr('height', 24)
    .attr(
      'xlink:href',
      './assets/system-icon-filled-icons-alert-icon-positive.svg'
    );

  text.on('click', function () {
    console.log('here');
    if (count === 1) {
      // posY += 150;
    }
    if (count > 1) {
      // posX += 300;
    }

    drawGreyedOutGraphNode(
      main,
      dialog,
      posX,
      posY,
      'child' + count,
      lineX1,
      lineY1,
      lineX2,
      lineY2
    );

    if (count > 1) {
      // lineX1 += 300;
      // lineX2 += 300;
    }
    count++;
  });

  editImg.on('click', function () {
    const dialogRef = dialog.open(DialogBoxComponent, {
      width: '100%',
      data: {
        content: document.querySelector('#textBox').children[0]['innerHTML'],
        title: 'Edit Textbox',
      },
    });

    dialogRef.afterClosed().subscribe((contentChange) => {
      text['_groups'][0][0].innerHTML = contentChange;
    });
  });
};

export const drawGreyedOutGraphNode = (
  svgRef: ElementRef<SVGElement>,
  dialog: MatDialog,
  posX: any,
  posY: any,
  id: String,
  lineX1: any,
  lineY1: any,
  lineX2: any,
  lineY2: any
): void => {
  let block;
  if (svgRef.nativeElement === undefined) {
    block = d3
      .select(svgRef['_groups'][0][0])
      .append('div')
      .attr('class', id + ' child_block');
  } else {
    block = d3.select(svgRef.nativeElement).append('div').attr('class', id);
  }

  const svgContainer = block
    .append('div')
    .attr('style', 'height: 135px')
    .append('svg')
    .attr('id', id)
    .attr('width', 400)
    .attr('height', 135)
    .append('g');

  const lineBlock = block
    .append('div')
    .attr('class', 'lineBlock' + id.replace('child', ''))
    .attr(
      'style',
      'position:absolute; width: 100%; height: 5px; top: 34px; left: 180px; border-top: 2px solid grey; opacity: 0.3; display: none'
    );

  const main = block.append('div').attr('class', 'main_block');

  //Draw the Rectangle
  const rectangle = svgContainer
    .append('rect')
    .attr('x', posX + 20)
    .attr('y', posY)
    .attr('width', 212)
    .attr('height', 64)
    .attr('style', 'fill:none')
    .attr('stroke', 'black')
    // .attr('stroke-dasharray', '5,5')
    .attr('opacity', 0.3)
    .attr('stroke-width', '1');

  const text = svgContainer
    .append('foreignObject')
    .attr('width', 200)
    .attr('height', 100)
    .attr('x', posX + 30)
    .attr('y', posY)
    .attr('id', 'textBox' + id.replace('child', ''))
    //.attr('style', 'grey')
    .append('xhtml:body')
    // .html('<span> hello[&times;10<sup>-15</sup> ss<sup>-1</sup>]</span>');
    .html(longText);

  const editImg = svgContainer
    .append('svg:image')
    .attr('class', 'textEdit')
    .attr('x', posX + 205)
    .attr('y', posY)
    .attr('width', 24)
    .attr('height', 24)
    .attr('xlink:href', './assets/edit-24-px.svg');

  const defs = svgContainer.append('defs');

  const marker = defs
    .append('marker')
    .attr('id', 'arrowhead')
    .attr('markerWidth', '10')
    .attr('markerHeight', '7')
    .attr('refX', '0')
    .attr('refY', '3.5')
    .attr('orient', 'auto');

  marker.append('polygon').attr('points', '0 0, 10 3.5, 0 7');

  if (id.indexOf('1') !== -1) {
    svgContainer
      .append('line')
      .attr('x1', lineX1)
      .attr('y1', lineY1)
      .attr('x2', lineX2)
      .attr('y2', lineY2)
      .attr('style', 'fill:none')
      .attr('stroke', 'black')
      .attr('stroke-width', '1')
      .attr('opacity', 0.3)
      .attr('marker-end', 'url(#arrowhead)');
  } else {
    svgContainer
      .append('line')
      .attr('x1', lineX1)
      .attr('y1', lineY1 + 35)
      .attr('x2', lineX2)
      .attr('y2', lineY2)
      .attr('style', 'fill:none')
      .attr('stroke', 'black')
      .attr('stroke-width', '1')
      .attr('opacity', 0.3)
      .attr('marker-end', 'url(#arrowhead)');

    let c = parseInt(id.replace('child', ''));
    console.log(id);
    console.log(lineBlock['_groups'][0][0].parentNode.parentNode);
    console.log(
      lineBlock['_groups'][0][0].parentNode.parentNode.childNodes[c - 2]
    );
    console.log(
      lineBlock['_groups'][0][0].parentNode.parentNode.childNodes[
        c - 2
      ].querySelector('.lineBlock' + (c - 1))
    );
    lineBlock['_groups'][0][0].parentNode.parentNode.childNodes[
      c - 2
    ].querySelector('.lineBlock' + (c - 1)).style.display = 'block';
  }

  let count = 1;
  let childPosX = posX;
  let childPosY = posY;
  let childLineX1 = lineX1;
  let childLineX2 = lineX2;
  let childLineY1 = lineY1;
  let childLineY2 = lineY2;
  text.on('click', function () {
    console.log('there');
    if (count === 1) {
      // childPosY += 150;
      if (id.indexOf('1') === -1) {
        // childLineX1 += 300;
        // childLineX2 += 300;
      }
    }
    if (count > 1) {
      // childPosX += 300;
    }

    drawGreyedOutGraphNode(
      main,
      dialog,
      childPosX,
      childPosY,
      'child' + count,
      childLineX1,
      childLineY1,
      childLineX2,
      childLineY2
    );

    if (count > 1) {
      // childLineX1 += 300;
      // childLineX2 += 300;
    }
    count++;
  });

  editImg.on('click', function () {
    const dialogRef = dialog.open(DialogBoxComponent, {
      width: '100%',
      data: {
        content: document.querySelector('#textBox' + id.replace('child', ''))
          .children[0]['innerHTML'],
        title: 'Edit Textbox',
      },
    });

    dialogRef.afterClosed().subscribe((contentChange) => {
      text['_groups'][0][0].innerHTML = contentChange;
    });
  });
};
