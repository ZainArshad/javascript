import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FlexLayoutModule } from '@angular/flex-layout';
import { FormsModule } from '@angular/forms';

import { MaterialModule } from './material.module';
import { NavbarComponent } from '../components/layout/navbar/navbar.component';
import { SidebarComponent } from '../components/layout/sidebar/sidebar.component';
import { GraphComponent } from '../components/graph/graph.component';
import { ListItemComponent } from '../components/layout/sidebar/list-item/list-item.component';



@NgModule({
  declarations: [
    NavbarComponent,
    SidebarComponent,
    GraphComponent,
    ListItemComponent],
  imports: [
    CommonModule,
    MaterialModule,
    FlexLayoutModule,
    FormsModule
  ],
  exports: [MaterialModule, FlexLayoutModule,NavbarComponent,
    SidebarComponent,
    GraphComponent,
    ListItemComponent]
})
export class SharedModule { }
