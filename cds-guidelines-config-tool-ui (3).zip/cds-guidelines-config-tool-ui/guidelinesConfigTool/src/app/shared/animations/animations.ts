import { trigger, transition, animate, style, state } from '@angular/animations';

export const animateDrawerButton = trigger('openClose', [
  state('open', style({ right: '200px' })),
  state('close', style({ right: '0' })),
  transition('open => closed', [animate('200ms ease-out')]),
  transition('closed => open', [animate('200ms ease-out')])
]);
