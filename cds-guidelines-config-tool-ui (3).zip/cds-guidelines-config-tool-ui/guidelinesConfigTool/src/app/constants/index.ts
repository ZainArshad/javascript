export const BASE_NODE_URL = 'node';
export const BASE_GUIDELINE_URL = 'guideline';
