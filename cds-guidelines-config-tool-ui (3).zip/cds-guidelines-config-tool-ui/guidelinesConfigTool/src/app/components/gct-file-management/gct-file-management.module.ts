import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CreateGuidelineComponent, CreateGuidelineDialogComponent } from './create-guideline/create-guideline.component';
import { GuidelineListComponent } from './guideline-list/guideline-list.component';
import { SharedModule } from '../../shared/shared.module';
import { GCTFileManagementComponent } from './gct-file-management.component';
import { GCTFileManagementRoutingModule } from './gct-file-management-routing.module';

const components = [
  CreateGuidelineComponent,
  CreateGuidelineDialogComponent,
  GuidelineListComponent,
  GCTFileManagementComponent,
];

@NgModule({
  declarations: [
    ...components
  ],
  imports: [
    CommonModule,
    SharedModule,
    GCTFileManagementRoutingModule
  ],
  exports: [
    ...components
  ]
})
export class GCTFileManagementModule { }
