import {Component, OnInit} from '@angular/core';
import { Store } from '@ngrx/store';

import { detailExpand, detailExpandArrow } from '../../../animations/animations';
import { State } from '../../../store/guideline-store/guideline.reducer';
import { loadAll, deleteGuidelineVersion } from '../../../store/guideline-store/guideline.actions';
import { selectGuidelineIsLoading, selectGuidelineListData } from '../../../store/guideline-store/guideline.selectors';
import { Observable } from 'rxjs';
import { GuidelineListData } from '../../../models/business/guideline-list-data';
import { CreateGuidelineDialogComponent } from '../../gct-file-management/create-guideline/create-guideline.component';
import { MatDialog } from '@angular/material/dialog';
import { GuidelineType } from '../../../models/dto/guideline-type';
import { Router } from '@angular/router';

/**
 * @title Table with expandable rows
 */
@Component({
  selector: 'app-guideline-list',
  templateUrl: './guideline-list.component.html',
  styleUrls: ['./guideline-list.component.scss'],
  animations: [detailExpand, detailExpandArrow],
})
export class GuidelineListComponent implements OnInit {
  guidelinesData$: Observable<GuidelineListData[]>;
  isLoading$: Observable<boolean>;
  columnsToDisplay = ['arrow', 'cancerType', 'version', 'modified', 'created', 'actions'];
  innerColumnsToDisplay = ['innerArrow', 'innerCancerType', 'innerVersion', 'innerModified', 'innerCreated', 'innerActions'];
  expandedElement: GuidelineListData | null;

  constructor(private store: Store<State>, public dialog: MatDialog, private _router: Router) {
    this.guidelinesData$ = this.store.select(selectGuidelineListData);
    this.isLoading$ = this.store.select(selectGuidelineIsLoading);
  }

  openDialog(guidelineType: GuidelineType): void {
    this.dialog.open(CreateGuidelineDialogComponent, { width: '50%', height: 'auto', data: guidelineType });
  }

  delete(guidelineVersionId: number): void {
    this.store.dispatch(deleteGuidelineVersion({ guidelineVersionId }));
  }

  ngOnInit(): void {
    this.store.dispatch(loadAll());
  }

  navigateToEditor(): void {
    this._router.navigate(['/gctEditor']);
  }
}
