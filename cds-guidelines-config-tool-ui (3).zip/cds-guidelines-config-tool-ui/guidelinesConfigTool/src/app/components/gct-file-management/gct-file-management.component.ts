import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-gct-file-management',
  templateUrl: './gct-file-management.component.html',
  styleUrls: ['./gct-file-management.component.scss']
})
export class GCTFileManagementComponent implements OnInit {

  constructor(private _router: Router) { }

  ngOnInit(): void { }

  public navigateToGCTEditor(): void  {
    this._router.navigate([{outlets: {GCTElement: 'editor'}}]);
  }


}
