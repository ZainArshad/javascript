import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DialogBoxComponent } from './dialog-box.component'
import { SharedModule } from '../../../shared/shared.module';
import { TextEditorModule } from '../text-editor/text-editor.module';

@NgModule({
  declarations: [DialogBoxComponent],
  imports: [
    CommonModule, SharedModule, TextEditorModule
  ],
  exports: [DialogBoxComponent]
})
export class DialogBoxModule { }
