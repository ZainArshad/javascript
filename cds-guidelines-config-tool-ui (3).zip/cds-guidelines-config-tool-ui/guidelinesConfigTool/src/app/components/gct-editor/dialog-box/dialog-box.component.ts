import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-dialog-box',
  templateUrl: './dialog-box.component.html',
  styleUrls: ['./dialog-box.component.scss']
})
export class DialogBoxComponent implements OnInit {
  contentChange: string;
  constructor(public dialogRef: MatDialogRef<DialogBoxComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

  ngOnInit(): void {
  }

  onCancel(): void {
    if(!this.contentChange){
      this.contentChange=this.data.content;
    }
    this.dialogRef.close(this.data.content);
  }

  onSave(): void {
    if(!this.contentChange){
      this.contentChange=this.data.content;
    }
    this.dialogRef.close(this.contentChange);
  }

  contentChanged(event){
    this.contentChange = event;
  }

}
