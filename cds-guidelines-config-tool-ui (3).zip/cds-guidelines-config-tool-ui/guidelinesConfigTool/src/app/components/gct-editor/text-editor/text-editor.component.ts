import { Component, OnInit, Inject, Output, EventEmitter, Input } from '@angular/core';



@Component({
  selector: 'app-text-editor',
  templateUrl: './text-editor.component.html',
  styleUrls: ['./text-editor.component.scss']
})
export class TextEditorComponent implements OnInit {
  @Input() dataModel: string;
  @Output() contentChanged: EventEmitter<any> = new EventEmitter();
  constructor() { }

  ngOnInit(): void {
    this.dataModel = String(this.dataModel)
  }

  handleEvent = (content) => {
    this.contentChanged.emit(this.dataModel);
  }  
}
