import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Store } from '@ngrx/store';
import { Router } from '@angular/router';
import * as fromNodeState from '../../store/node-store/node.reducer';


@Component({
  selector: 'app-gct-editor',
  templateUrl: './gct-editor.component.html',
  styleUrls: ['./gct-editor.component.scss']
})
export class GCTEditorComponent implements OnInit {

  guidelineTitle = '';
  isOpen = true;

  constructor(private _router: Router, private store: Store<fromNodeState.State>){ }
  ngOnInit(): void {
    this._router.initialNavigation();
    this.guidelineTitle = 'Test Guideline';
  }

  addAppendixHandler(): void {
    console.log('Parent received event to add appendix');
  }

  previewHandler(): void {
    console.log('Parent received event to add preview');
  }

  toggleSidenavHandler(): void {
    this.isOpen = !this.isOpen;
  }


}
