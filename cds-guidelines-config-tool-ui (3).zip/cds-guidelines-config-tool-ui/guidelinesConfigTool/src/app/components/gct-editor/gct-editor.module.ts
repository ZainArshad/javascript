import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GCTEditorComponent } from './gct-editor.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { TextEditorModule } from './text-editor/text-editor.module';
import { DialogBoxModule } from './dialog-box/dialog-box.module';
import { GCTEditorRoutingModule } from './gct-editor-routing.module';

const components = [
  GCTEditorComponent,
];
@NgModule({
  declarations: [
    ...components
  ],
  imports: [
    CommonModule,
    SharedModule,
    TextEditorModule,
    DialogBoxModule,
    GCTEditorRoutingModule
  ],
  exports: [
    ...components
  ]
})
export class GCTEditorModule { }
