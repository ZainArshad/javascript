import { Component, OnInit, ViewChild, Input, OnChanges, SimpleChanges } from '@angular/core';
import { animateDrawerButton } from '../../../animations/animations';
import { MatSidenav } from '@angular/material/sidenav';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss'],
  animations: [animateDrawerButton]
})
export class SidebarComponent implements OnInit, OnChanges {

  @ViewChild('drawer') drawer: MatSidenav;
  @Input() isOpen: boolean;

  constructor() { }

  ngOnInit(): void {
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.isOpen && changes.isOpen.previousValue !== undefined && changes.isOpen.currentValue !== changes.isOpen.previousValue) {
      this.drawer.toggle();
    }
  }
  
}
