import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss']
})
export class NavbarComponent implements OnInit {

  @Output() addAppendix = new EventEmitter();
  @Output() preview = new EventEmitter();
  @Output() toggleSidenav = new EventEmitter();

  @Input() guidelineTitle: string;

  constructor() { }

  ngOnInit(): void {
  }

  addAppendixHandler(): void {
    this.addAppendix.emit();
  }

  previewHandler(): void {
    this.preview.emit();
  }

  toggleSidenavHandler(): void {
    this.toggleSidenav.emit();
  }
}
