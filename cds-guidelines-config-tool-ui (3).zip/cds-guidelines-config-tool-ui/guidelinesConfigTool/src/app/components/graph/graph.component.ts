import {
  Component,
  OnInit,
  AfterViewInit,
  ViewChild,
  ElementRef,
  Renderer2,
} from '@angular/core';
import * as Utils from '../../d3/d3.graph.utils';
import { GraphNode } from '../../d3/models/graph';
import { MatDialog } from '@angular/material/dialog';
import { DialogBoxComponent } from '../gct-editor/dialog-box/dialog-box.component';

@Component({
  selector: 'app-graph',
  templateUrl: './graph.component.html',
  styleUrls: ['./graph.component.scss'],
})
export class GraphComponent implements OnInit, AfterViewInit {
  // @Input('nodes') nodes;
  // @Input('links') links;
  graphNode: GraphNode = {
    id: 1,
    content: '',
    children: [],
    parentId: 1,
    size : {width: 212, height: 64},
    width : 212,
    height : 64,
    x: 50,
    y: 70,
    position: {x: 0, y: 0},
    vx: 0,
    vy: 0,
    fx: 0,
    fy: 0
};

  @ViewChild('svg') svgRef: ElementRef<SVGElement>;

  constructor(public renderer: Renderer2, public dialog: MatDialog) {
    
  }

  ngOnInit(): void {}


  ngAfterViewInit(): void {
    this.drawGraphNodes();
  }

  public drawGraphNodes(): void {
    Utils.createGraphNode(this.svgRef, this.graphNode, this.dialog);
    //Utils.createGraph(this.svgRef, this.graphNode);
    // this.renderer.listen(this.svgRef.nativeElement.querySelector('#textEdit'), 'click', (event) => {
    //   let content = this.svgRef.nativeElement.querySelector('#textBox').children[0]['innerHTML'];
    //   this.openDialog(content);
    // })
  }

// Diolog for text editor
openDialog(content): void {
  const dialogRef = this.dialog.open(DialogBoxComponent, {
    width: '100%',
    data: { content: content, title: "Edit Textbox" }
  });

  dialogRef.afterClosed().subscribe(contentChange => {
    this.svgRef.nativeElement.querySelector('#textBox').innerHTML = `<pre>${contentChange}</pre>`;
    this.svgRef.nativeElement.querySelector('#textBox').setAttribute('height','500px');
  });
}
}
