import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { ResourceBaseService } from './resource-base.service';
import { GuidelineType } from '../models/dto/guideline-type';
import { HttpClient } from '@angular/common/http';
import { BASE_GUIDELINE_URL } from '../constants';
import { APIResponse } from '../models/http/api-response';

@Injectable({
  providedIn: 'root'
})
export class GuidelineTypeService extends ResourceBaseService<GuidelineType> {

  constructor(httpClient: HttpClient) {
    super(httpClient, BASE_GUIDELINE_URL);
  }

  // Custom API's for specific entity API's that don't fit ResourceBaseService class


  loadGuidelineTypes(): Observable<GuidelineType[]> {
    return this.httpClient
      .get<APIResponse>(`${this.basePath}/list`)
      .pipe(map((res: APIResponse) => this.toDtos(res)));
  }
}
