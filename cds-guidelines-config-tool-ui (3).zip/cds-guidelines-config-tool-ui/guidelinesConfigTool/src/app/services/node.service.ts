import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { ResourceBaseService } from './resource-base.service';
import { Node } from '../models/dto/node';
import { BASE_NODE_URL } from '../constants';

@Injectable({
  providedIn: 'root'
})
export class NodeService extends ResourceBaseService<Node> {

  constructor(httpClient: HttpClient) {
    super(httpClient, BASE_NODE_URL);
  }

  // Custom API's for specific entity API's that don't fit ResourceBaseService class

}
