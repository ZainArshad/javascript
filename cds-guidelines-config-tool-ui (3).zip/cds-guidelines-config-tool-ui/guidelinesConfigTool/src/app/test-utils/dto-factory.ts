import { Node } from '../models/dto/node';
import { Guideline } from '../models/dto/guideline';
import { GuidelineVersion } from '../models/dto/guideline-version';
import { GuidelineType } from '../models/dto/guideline-type';

// Given
export const CONTENT_A = 'nodeA content';
export const CONTENT_B = 'nodeB content';
export const UPDATED_CONTENT = 'Updated';
export const PRIMARY_ID = 1;
export const SECONDARY_ID = 2;
export const INDEX_0 = 0;
export const INDEX_1 = 1;
export const GUIDELINE_TYPE_NAME = 'Test';
export const CATEGORY = 'category';
export const CREATED_DATE = new Date();

// Factory
export const createNodeA = (): Node => {
  return {
    id: PRIMARY_ID,
    version: 0,
    content: CONTENT_A,
    outgoingNodeIds: [2],
    tableItem: null,
    footnotes: null,
    section: null,
    index: INDEX_0,
    guidelineId: null
  };
};

export const createNodeB = (): Node => {
  return {
    id: SECONDARY_ID,
    version: 0,
    content: CONTENT_B,
    outgoingNodeIds: [],
    tableItem: null,
    footnotes: null,
    section: null,
    index: INDEX_1,
    guidelineId: null
  };
};

export const createGuidelineA = (): Guideline => {
  const guidelineVersion = createGuidelineVersionA();
  // const tableItems = createTableItems();
  return {
    id: PRIMARY_ID,
    createdDate: CREATED_DATE,
    guidelineVersion,
    tableItems: null,
    removed: false
  };
};

export const createGuidelineB = (): Guideline => {
  const guidelineVersion = createGuidelineVersionB();
  // const tableItems = createTableItems();
  return {
    id: SECONDARY_ID,
    createdDate: CREATED_DATE,
    guidelineVersion,
    tableItems: null,
    removed: false
  };
};

export const createGuidelineVersionA = (): GuidelineVersion => {
  const guidelineType = createGuidelineType();
  return {
    id: PRIMARY_ID,
    guidelineType,
    createdDate: CREATED_DATE,
    updates: [],
    removed: false
  };
};

export const createGuidelineVersionB = (): GuidelineVersion => {
  const guidelineType = createGuidelineType();
  return {
    id: SECONDARY_ID,
    guidelineType,
    createdDate: CREATED_DATE,
    updates: [],
    removed: false
  };
};

export const createGuidelineType = (): GuidelineType => {
  return {
    id: PRIMARY_ID,
    name: GUIDELINE_TYPE_NAME,
    snomedAssociatedMorphologies: ['12345'],
    snomedFindingSite: 'test',
    category: CATEGORY,
    removed: false
  };
};

