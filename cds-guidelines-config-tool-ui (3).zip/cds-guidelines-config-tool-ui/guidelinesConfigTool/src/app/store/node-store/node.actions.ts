import { createAction, props } from '@ngrx/store';

import { Node } from '../../models/dto/node';
import { NodeActionTypes } from './node.types';

export const select = createAction(
  NodeActionTypes.SELECT,
  props<{ activeNode: Node }>()
);

export const create = createAction(
  NodeActionTypes.CREATE,
  props<{ node: Node }>()
);

export const update = createAction(
  NodeActionTypes.UPDATE,
  props<{ id: number, changes: Node }>()
);

export const remove = createAction(
  NodeActionTypes.REMOVE,
  props<{ node: Node }>()
);

// Todo make this a response not just a node
export const createSucceeded = createAction(
  NodeActionTypes.CREATE_SUCCESS,
  props<{ node: Node }>()
);

export const removeSucceeded = createAction(
  NodeActionTypes.REMOVE_SUCCESS,
  props<{ node: Node }>()
);

export const updateSucceeded = createAction(
  NodeActionTypes.UPDATE_SUCCESS,
  props<{ id: number, changes: Partial<Node> }>()
);

export const createFailed = createAction(
  NodeActionTypes.CREATE_FAILURE,
  props<{ errors: string | string[] }>()
);

export const removeFailed = createAction(
  NodeActionTypes.REMOVE_FAILURE,
  props<{ errors: string | string[] }>()
);

export const updateFailed = createAction(
  NodeActionTypes.UPDATE_FAILURE,
  props<{ errors: string | string[] }>()
);



