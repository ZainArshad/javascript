import { Action } from '@ngrx/store';
import { Node } from '../../models/dto/node';

export enum NodeActionTypes {
  SELECT = '[Nodes] Select',
  CREATE = '[Nodes] Create',
  CREATE_SUCCESS = '[Nodes] Create Success',
  CREATE_FAILURE = '[Nodes] Create Failure',
  UPDATE = '[Nodes] Update',
  UPDATE_SUCCESS = '[Nodes] Update Success',
  UPDATE_FAILURE = '[Nodes] Update Failure',
  REMOVE = '[Nodes] Remove',
  REMOVE_SUCCESS = '[Nodes] Remove Success',
  REMOVE_FAILURE = '[Nodes] Remove Failure'
}

export interface NodeCreatePayload {
  node: Node;
}

export interface NodeUpdatePayload {
  id: number;
  changes: Node;
}

