import { createReducer, on, Action } from '@ngrx/store';
import { EntityState, EntityAdapter, createEntityAdapter } from '@ngrx/entity';

import { Node } from '../../models/dto/node';
import * as NodeActions from './node.actions';

export interface State extends EntityState<Node> {
  activeNode: Node;
  isLoading: boolean;
  errors: string | string[];
}
export const adapter: EntityAdapter<Node> = createEntityAdapter<Node>();
const initialState: State = {
  ...adapter.getInitialState(),
  activeNode: null,
  isLoading: false,
  errors: []
};

export const nodeFeatureKey = 'node';

const nodeReducer = createReducer(
  initialState,
  on(
    NodeActions.createSucceeded,
    (state, { node }) => adapter.addOne(node, state)
  ),
  on(
    NodeActions.removeSucceeded,
    (state, { node }) => adapter.removeOne(node.id, state)
  ),
  on(
    NodeActions.select,
    (state, { activeNode }) => ({ ...state, activeNode })
  ),
  on(
    NodeActions.updateSucceeded,
    (state, { id, changes }) => adapter.updateOne({ id, changes}, state)
  ),
  on(
    NodeActions.createFailed,
    (state, { errors }) => ({ ...state, errors })
  ),
  on(
    NodeActions.removeFailed,
    (state, { errors }) => ({ ...state, errors })
  ),
  on(
    NodeActions.updateFailed,
    (state, { errors }) => ({ ...state, errors })
  )
);

export const reducer = (state: State | undefined, action: Action) => nodeReducer(state, action);
