import { Injectable } from '@angular/core';
import { Actions, ofType, createEffect } from '@ngrx/effects';

import { NodeService } from '../../services/node.service';
import * as NodeActions from './node.actions';
import { switchMap, catchError, map } from 'rxjs/operators';
import { of } from 'rxjs';
import { NodeUpdatePayload, NodeCreatePayload } from './node.types';

@Injectable()
export class NodeEffects {
  constructor(private nodeService: NodeService, private actions$: Actions) { }

  createNode$ = createEffect(() =>
    this.actions$.pipe(
      ofType(NodeActions.create),
      switchMap((payload: NodeCreatePayload) =>
        this.nodeService.create(payload.node)
          .pipe(
            map(node => NodeActions.createSucceeded({ node })),
            catchError((errors: any) => of(NodeActions.createFailed({ errors })))
          )
      )
    )
  );

  updateNode$ = createEffect(() =>
    this.actions$.pipe(
      ofType(NodeActions.update),
      switchMap((payload: NodeUpdatePayload) =>
        this.nodeService.update(payload.changes)
          .pipe(
            map(node => NodeActions.updateSucceeded({ id: payload.id, changes: node })),
            catchError((errors: any) => of(NodeActions.updateFailed({ errors })))
          )
      )
    )
  );
}
