import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { NodeEffects } from './node-store/node.effects';
import { GuidelineEffects } from './guideline-store/guideline.effects';
import { reducer as nodeReducer, nodeFeatureKey } from './node-store/node.reducer';
import { reducer as guidelineReducer, guidelineFeatureKey } from './guideline-store/guideline.reducer';

@NgModule({
  imports: [
    CommonModule,
    StoreModule.forFeature(nodeFeatureKey, nodeReducer),
    StoreModule.forFeature(guidelineFeatureKey, guidelineReducer),
    EffectsModule.forFeature([NodeEffects, GuidelineEffects])
  ],
  exports: [StoreModule, EffectsModule],
  declarations: []
})
export class RootStoreModule { }

