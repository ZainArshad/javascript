import { Injectable } from '@angular/core';
import { Actions, ofType, createEffect } from '@ngrx/effects';
import { switchMap, catchError, map } from 'rxjs/operators';
import { of, Observable, forkJoin } from 'rxjs';

import { GuidelineService } from '../../services/guideline.service';
import { GuidelineTypeService } from '../../services/guideline-type.service';
import { GuidelineVersionService } from '../../services/guideline-version.service';
import * as GuidelineActions from './guideline.actions';
import { Guideline } from '../../models/dto/guideline';
import { GuidelineType } from '../../models/dto/guideline-type';
import { GuidelineVersion } from '../../models/dto/guideline-version';
import { GuidelineListData } from '../../models/business/guideline-list-data';
import {
  GuidelineCreatePayload,
  GuidelineLoadPayload,
  GuidelineTypeLoadAllPayload,
  GuidelineVersionDeletePayload
} from './guideline.types';


@Injectable()
export class GuidelineEffects {
  constructor(
    private guidelineService: GuidelineService,
    private guidelineTypeService: GuidelineTypeService,
    private guidelineVersionService: GuidelineVersionService,
    private actions$: Actions) { }

  createGuideline$ = createEffect(() =>
    this.actions$.pipe(
      ofType(GuidelineActions.create),
      switchMap((payload: GuidelineCreatePayload) =>
        this.guidelineService.create(payload.guideline)
          .pipe(
            map((guideline: Guideline) => GuidelineActions.loadAll()),
            catchError((errors: any) => of(GuidelineActions.createFailed({ errors })))
          )
      )
    )
  );

  loadGuideline$ = createEffect(() =>
    this.actions$.pipe(
      ofType(GuidelineActions.load),
      switchMap((payload: GuidelineLoadPayload) =>
        this.guidelineService.getById(payload.id)
          .pipe(
            map((guideline: Guideline) => GuidelineActions.loadSucceeded({ guideline })),
            catchError((errors: any) => of(GuidelineActions.loadFailed({ errors })))
          )
      )
    )
  );

  loadAll$ = createEffect(() =>
    this.actions$.pipe(
      ofType(GuidelineActions.loadAll),
      switchMap(() =>
        this.guidelineTypeService.loadGuidelineTypes()
          .pipe(
            map((guidelineTypes: GuidelineType[]) => {
              return GuidelineActions.loadAllGuidelineVersions({ guidelineTypes });
            }),
            catchError(( errors: any) => of(GuidelineActions.loadFailed({ errors })))
          )
      )
    )
  );

  loadAllGuidelineVersions$ = createEffect(() =>
    this.actions$.pipe(
      ofType(GuidelineActions.loadAllGuidelineVersions),
      switchMap((payload: GuidelineTypeLoadAllPayload) =>
        this.loadByGuidelineTypeHelper(payload.guidelineTypes)
          .pipe(
            map((guidelineVersions: GuidelineVersion[]) => {
              guidelineVersions = [].concat(...guidelineVersions);
              const guidelineListData: GuidelineListData[] = this.formatToGuidelineData(guidelineVersions, payload.guidelineTypes);
              return GuidelineActions.loadGuidelineListDataSucceeded(
                {
                  guidelineVersions,
                  guidelineTypes: payload.guidelineTypes,
                  guidelineListData
                }
              );
            }),
            catchError(( errors: any) => of(GuidelineActions.loadFailed({ errors })))
          )
      )
    )
  );

  deleteGuidelineVersion$ = createEffect(() =>
    this.actions$.pipe(
      ofType(GuidelineActions.deleteGuidelineVersion),
      switchMap((payload: GuidelineVersionDeletePayload) =>
        this.guidelineVersionService.delete(payload.guidelineVersionId)
          .pipe(
            map(() => {
              GuidelineActions.deleteGuidelineVersionSucceeded();
              return GuidelineActions.loadAll();
            }),
            catchError((errors: any) => of(GuidelineActions.deleteGuidelineVersionFailed({ errors })))
          )
      )
    )
  );

  private formatToGuidelineData(versions: GuidelineVersion[], guidelineTypes: GuidelineType[]): GuidelineListData[] {
    const guidelineListData: GuidelineListData[] = [];
    guidelineTypes.forEach((guidelineType) => {
      const guidelineVersions = versions
        .filter(version => version.guidelineTypeId === guidelineType.guidelineTypeId)
        .sort((a: GuidelineVersion, b: GuidelineVersion) => new Date(b.createdDate).getTime() - new Date(a.createdDate).getTime());
      const latestVersion = guidelineVersions.length ? guidelineVersions[0] : null;

      if (latestVersion) {
        guidelineListData.push({
          guidelineType,
          latestVersion,
          guidelineVersions
        });
      }
    });
    return guidelineListData;
  }

  private loadByGuidelineTypeHelper(guidelineTypes: GuidelineType[]): Observable<any[]> {
    const observables: Observable<any>[] = [];
    guidelineTypes
      .forEach((type) => {
        observables.push(
          this.guidelineVersionService.loadGuidelineVersionsByGuidelineType(type.guidelineTypeId)
        );
      });
    return forkJoin(observables);
  }
}
